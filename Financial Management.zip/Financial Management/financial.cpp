#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <vector>

using namespace std;

class userData
{
public:
   string name;
   string desi;
   int age;
   float salary;

   void setData()
   {
      cout << "Enter name: ";
      cin >> name;
      cout << "Enter Designation: ";
      cin >> desi;
      cout << "Enter Age: ";
      cin >> age;
      cout << "Enter Salary: ";
      cin >> salary;
      cin.ignore();
   }

   friend ostream &operator<<(ostream &os, const userData &user)
   {
      os << "Name: " << user.name << "\nDesignation: " << user.desi << "\nAge: " << user.age << "\nSalary: " << user.salary << "\n";
      os << "________________________________________________________________________________________________________________________________" << "\n";
      os << "Date      " << left << setw(25) << "  Education Expense" << setw(15) << "Food Expense" << setw(15) << "Grocery Expense   " << setw(20) << "Stationery Expense" << setw(15) << "Other Expense" << setw(15) << "Day Total"
         << "\n";
      return os;
   }
};

class expense : public userData
{
public:
   string date;
   double edu, food, grocery, sta, other, Daytotal, monthtotal = 0.0, saving = 0.0;

   void setexp()
   {
      cout << "Enter date: ";
      cin.ignore();
      getline(cin, date);
      cout << "Enter Education Expense: ";
      cin >> edu;
      cout << "Enter Food Expense: ";
      cin >> food;
      cout << "Enter Grocery Expense: ";
      cin >> grocery;
      cout << "Enter Stationery Expense: ";
      cin >> sta;
      cout << "Enter Other Expense: ";
      cin >> other;
      Daytotal = edu + food + grocery + sta + other;
      monthtotal += Daytotal;
      saving = salary - monthtotal;
   }

   friend ostream &operator<<(ostream &os, const expense &exp)
   {
      os << left << exp.date << "  " << setw(25) << exp.edu << setw(15) << exp.food << setw(15) << exp.grocery << setw(20) << exp.sta << setw(15) << exp.other << setw(15) << exp.Daytotal << "\n";
      return os;
   }
};

double savingfun(double a)
{
   return (a * 25) / 100;
}

int main()
{
   vector<userData> users;
   vector<expense> expenses;
   int choice;
   double monthdatastore = 0.0;
   double monthlysavingstore = 0.0;
   double savingstore = 0.0;
   fstream resultFile;

   try
   {
      resultFile.open("C:\\Users\\Natish\\OneDrive\\Desktop\\financial_management_result.txt", ios::out | ios::app);
   }
   catch (const std::exception &e)
   {
      std::cerr << e.what() << '\n';
   }

   do
   {
      cout << "1 Enter User data" << endl;
      cout << "2 Enter Expense" << endl;
      cout << "3 Modify user data" << endl;
      cout << "4 Modify Expense data" << endl;
      cout << "5 Clear all data" << endl;
      cout << "6 Exit " << endl;
      cin >> choice;

      switch (choice)
      {
      case 1:
      {
         userData a;
         a.setData();
         savingstore = a.salary;
         users.push_back(a);
         break;
      }
      case 2:
      {
         expense b;
         b.setexp();
         expenses.push_back(b);
         monthdatastore += b.Daytotal;
         monthlysavingstore = savingstore - monthdatastore;
         break;
      }
      case 3:
      {
         userData c;
         c.setData();
         users.clear();
         users.push_back(c);
         break;
      }
      case 4:
      {
         string modifyDate;
         cout << "Enter the date to modify: ";
         cin.ignore();
         getline(cin, modifyDate);

         bool found = false;
         for (int i = 0; i < expenses.size(); i++)
         {
            if (expenses[i].date == modifyDate)
            {
               cout << "Enter modified Expense data for date " << modifyDate << ":\n";
               expenses[i].setexp();
               monthdatastore += expenses[i].Daytotal;
               monthlysavingstore = savingstore - monthdatastore;
               found = true;
               break;
            }
         }

         if (!found)
         {
            cout << "Expense data for date " << modifyDate << " not found.\n";
         }

         break;
      }
      case 5:
      {
         resultFile.clear();
         break;
      }
      case 6:
      {
         for (int i = 0; i < users.size(); i++)
         {
            resultFile << "User Data:\n"
                       << users[i];
         }
         for (int i = 0; i < expenses.size(); i++)
         {
            resultFile << expenses[i];
         }
         resultFile << "________________________________________________________________________________________________________________________________" << "\n";
         resultFile << "Month total " << monthdatastore << endl;
         resultFile << "Monthly Saving is " << monthlysavingstore << endl;
         if (monthlysavingstore >= savingfun(savingstore))
         {
            resultFile << "Good Money Saver " << endl;
         }
         else
         {
            resultFile << "Please spend money efficiently ";
         }
         break;
      }
      }
   } while (choice != 6);

   resultFile.close();
   return 0;
}
